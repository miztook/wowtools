DFA
===

Deterministic Finite Automata <br> 
very simple DFA implementation in pure C++


<i>Faraz Fallahi (fffaraz@gmail.com)</i>
